# -*- coding: utf-8 -*-
"""
Created on Sat Sep 19 11:09:37 2020

@author: Bryan Cuellar Moran 3IBA
"""
from tkinter import*
from tkinter.ttk import *

raiz=Tk()
raiz.title("DATOS COVID-19 POR ESTADO 25/SEP/2020")

#-----------------B O T O N E S-----------------------------------
selected=StringVar()

rad1=Radiobutton(raiz,text='Aguascalientes ',value= 'Aguascalientes', variable=selected)
rad2=Radiobutton(raiz,text='Baja California ',value= 'Baja California', variable=selected)
rad3=Radiobutton(raiz,text='Baja California Sur ',value= 'Baja California Sur', variable=selected)
rad4=Radiobutton(raiz,text='Campeche ',value= 'Campeche', variable=selected)
rad5=Radiobutton(raiz,text='Chiapas ',value= 'Chiapas', variable=selected)
rad6=Radiobutton(raiz,text='Chihuahua ',value= 'Chihuahua', variable=selected)
rad7=Radiobutton(raiz,text='Coahuila',value= 'Coahuila', variable=selected)
rad8=Radiobutton(raiz,text='Colima ',value= 'Colima', variable=selected)
rad9=Radiobutton(raiz,text='Ciudad de Mexico',value= 'Ciudad de Mexico', variable=selected)
rad10=Radiobutton(raiz,text='Durango ',value= 'Durango', variable=selected)
rad11=Radiobutton(raiz,text='Guanajuato ',value= 'Guanajuato', variable=selected)
rad12=Radiobutton(raiz,text='Guerrero ',value= 'Guerrero', variable=selected)
rad13=Radiobutton(raiz,text='Hidalgo ',value= 'Hidalgo', variable=selected)
rad14=Radiobutton(raiz,text='Jalisco ',value= 'Jalisco', variable=selected)
rad15=Radiobutton(raiz,text='Mexico ',value= 'Mexico', variable=selected)
rad16=Radiobutton(raiz,text='Michoacan ',value= 'Michoacan', variable=selected)
rad17=Radiobutton(raiz,text='Morelos ',value= 'Morelos', variable=selected)
rad18=Radiobutton(raiz,text='Nayarit ',value= 'Nayarit', variable=selected)
rad19=Radiobutton(raiz,text='Nuevo Leon ',value= 'Nuevo Leon', variable=selected)
rad20=Radiobutton(raiz,text='Oaxaca ',value= 'Oaxaca', variable=selected)
rad21=Radiobutton(raiz,text='Puebla ',value= 'Puebla', variable=selected)
rad22=Radiobutton(raiz,text='Queretaro ',value= 'Queretaro', variable=selected)
rad23=Radiobutton(raiz,text='Quintana Roo ',value= 'Quintana Roo', variable=selected)
rad24=Radiobutton(raiz,text='San Luis Potosi ',value= 'San Luis Potosi', variable=selected)
rad25=Radiobutton(raiz,text='Sinaloa ',value= 'Sinaloa', variable=selected)
rad26=Radiobutton(raiz,text='Sonora ',value= 'Sonora', variable=selected)
rad27=Radiobutton(raiz,text='Tabasco ',value= 'Tabasco', variable=selected)
rad28=Radiobutton(raiz,text='Tamaulipas ',value= 'Tamaulipas', variable=selected)
rad29=Radiobutton(raiz,text='Tlaxcala ',value= 'Tlaxcala', variable=selected)
rad30=Radiobutton(raiz,text='Veracruz ',value= 'Veracruz', variable=selected)
rad31=Radiobutton(raiz,text='Yucatan ',value= 'Yucatan', variable=selected)
rad32=Radiobutton(raiz,text='Zacatecas ',value= 'Zacatecas', variable=selected)

#-----------------------------------Pulsaciones-------------------------------
def clicked():
    a=selected.get()
    bolsa=['Aguascalientes','Baja California','Baja California Sur','Campeche','Chiapas','Chihuahua','Coahuila','Colima','Ciudad de Mexico','Durango','Guanajuato','Guerrero','Hidalgo','Jalisco','Mexico','Michoacan','Morelos','Nayarit','Nuevo Leon','Oaxaca','Puebla','Queretaro','Quintana Roo','San Luis Potosi','Sinaloa','Sonora','Tabasco','Tamaulipas','Tlaxcala','Veracruz','Yucatan','Zacatecas',]
    def linearSearch(a,bolsa):
        found = False
        position = 0
        while position < len(my_list) and not found:
            if my_list[position] == item:
                found = True
            position = position + 1
            return found
    if linearSearch:
        print(a)

        #1
        data={}
        data['Aguascalientes']=[]
        data['Aguascalientes'].append({
        'Contagios':6937,
        'Hospitalizados':1914,
        'Muertes':589,
        'Recuperados':4969})

        #2
        data['Baja California']=[]
        data['Baja California'].append({
        'Contagios':18921,
        'Hospitalizados':6555,
        'Muertes':3510,
        'Recuperados':12294})


        #3
        data['Baja California Sur']=[]
        data['Baja California Sur'].append({
        'Contagios':9904,
        'Hospitalizados':1181,
        'Muertes':448,
        'Recuperados':8316})

        #4
        data['Campeche']=[]
        data['Campeche'].append({
        'Contagios':5911,
        'Hospitalizados':1856,
        'Muertes':808,
        'Recuperados':4002})
    
        #5
        data['Chiapas']=[]
        data['Chiapas'].append({
        'Contagios':6501,
        'Hospitalizados':2393,
        'Muertes':1085,
        'Recuperados':4023})


        #6
        data['Chihuahua']=[]
        data['Chihuahua'].append({
        'Contagios':10428,
        'Hospitalizados':3294,
        'Muertes':1342,
        'Recuperados':7324})

        #7
        data['Coahuila']=[]
        data['Coahuila'].append({
        'Contagios':25532,
        'Hospitalizados':3831,
        'Muertes':1809,
        'Recuperados':21278})

        #8
        data['Colima']=[]
        data['Colima'].append({
        'Contagios':4646,
        'Hospitalizados':1350,
        'Muertes':514,
        'Recuperados':3207})


        #9
        data['Ciudad de Mexico']=[]
        data['Ciudad de Mexico'].append({
        'Contagios':121931,
        'Hospitalizados':21400,
        'Muertes':9479,
        'Recuperados':98906})

        #10
        data['Durango']=[]
        data['Durango'].append({
        'Contagios':8455,
        'Hospitalizados':1322,
        'Muertes':597,
        'Recuperados':6887})

        #11
        data['Guanajuato']=[]
        data['Guanajuato'].append({
        'Contagios':39841,
        'Hospitalizados':6271,
        'Muertes':2831,
        'Recuperados':32543})

        #12
        data['Guerrero']=[]
        data['Guerrero'].append({
        'Contagios':18180,
        'Hospitalizados':4092,
        'Muertes':1904,
        'Recuperados':13980})

        #13
        data['Hidalgo']=[]
        data['Hidalgo'].append({
        'Contagios':12426,
        'Hospitalizados':4499,
        'Muertes':1883,
        'Recuperados':7704})

        #14
        data['Jalisco']=[]
        data['Jalisco'].append({
        'Contagios':25730,
        'Hospitalizados':7987,
        'Muertes':3176,
        'Recuperados':17024})


        #15
        data['Mexico']=[]
        data['Mexico'].append({
        'Contagios':79223,
        'Hospitalizados':30669,
        'Muertes':11577,
        'Recuperados':47843})

        #16
        data['Michoacan']=[]
        data['Michoacan'].append({
        'Contagios':19647,
        'Hospitalizados':3879,
        'Muertes':1605,
        'Recuperados':15599})


        #17
        data['Morelos']=[]
        data['Morelos'].append({
        'Contagios':5845,
        'Hospitalizados':2557,
        'Muertes':1081,
        'Recuperados':3119})

        #18
        data['Nayarit']=[]
        data['Nayarit'].append({
        'Contagios':5844,
        'Hospitalizados':1925,
        'Muertes':724,
        'Recuperados':3833})

        #19
        data['Nuevo Leon']=[]
        data['Nuevo Leon'].append({
        'Contagios':37824,
        'Hospitalizados':7906,
        'Muertes':2935,
        'Recuperados':28585})

        # 20
        data['Oaxaca']=[]
        data['Oaxaca'].append({
        'Contagios':16341,
        'Hospitalizados':3438,
        'Muertes':1426,
        'Recuperados':12587})

        #21
        data['Puebla']=[]
        data['Puebla'].append({
        'Contagios':30665,
        'Hospitalizados':9061,
        'Muertes':3952,
        'Recuperados':20916})


        #22
        data['Queretaro']=[]
        data['Queretaro'].append({
        'Contagios':8708,
        'Hospitalizados':2598,
        'Muertes':908,
        'Recuperados':5884})

        #23
        data['Quintana Roo']=[]
        data['Quintana Roo'].append({
        'Contagios':11604,
        'Hospitalizados':3450,
        'Muertes':1624,
        'Recuperados':7943})

        #24
        data['San Luis Potosi']=[]
        data['San Luis Potosi'].append({
        'Contagios':22395,
        'Hospitalizados':3419,
        'Muertes':1639,
        'Recuperados':18654})

        #25
        data['Sinaloa']=[]
        data['Sinaloa'].append({
        'Contagios':18341,
        'Hospitalizados':6383,
        'Muertes':3120,
        'Recuperados':11692})

        #26
        data['Sonora']=[]
        data['Sonora'].append({
        'Contagios':24238,
        'Hospitalizados':5757,
        'Muertes':2846,
        'Recuperados':18082})

        #27
        data['Tabasco']=[]
        data['Tabasco'].append({
        'Contagios':31396,
        'Hospitalizados':4554,
        'Muertes':2739,
        'Recuperados':25872})


        #28
        data['Tamaulipas']=[]
        data['Tamaulipas'].append({
        'Contagios':28418,
        'Hospitalizados':4464,
        'Muertes':2138,
        'Recuperados':23456})

        #29
        data['Tlaxcala']=[]
        data['Tlaxcala'].append({
        'Contagios':7469,
        'Hospitalizados':2126,
        'Muertes':1087,
        'Recuperados':5114})

        #30
        data['Veracruz']=[]
        data['Veracruz'].append({
        'Contagios':32665,
        'Hospitalizados':11333,
        'Muertes':4249,
        'Recuperados':20831})


        #31
        data['Yucatan']=[]
        data['Yucatan'].append({
        'Contagios':17793,
        'Hospitalizados':3876,
        'Muertes':1530,
        'Recuperados':13346})

        #32
        data['Zacatecas']=[]
        data['Zacatecas'].append({
        'Contagios':7099,
        'Hospitalizados':1713,
        'Muertes':687,
        'Recuperados':5132})


    

        for i in data[a]:
            f=open(str(a)+"DatosCovid.txt","w")
            f.write("----Datos covid en el estado de " + str(a))
            f.write('\n Total de contagios ----------> '+ str(i['Contagios']))
            f.write('\n Total de hospitalizados------> '+ str(i['Hospitalizados']))
            f.write('\n Total de muertes ------------> '+ str(i['Muertes']))
            f.write('\n Total de recueperados -------> '+ str(i['Recuperados']))
            f.write("         ")
            f.close()
            print('Total de contagios ----------> ',i['Contagios'])
            print('Total de hospitalizados------> ',i['Hospitalizados'])
            print('Total de muertes ------------> ',i['Muertes'])
            print('Total de recueperados -------> ',i['Recuperados'])
            print(" ")

    else:
        print("No existe")
        print(a)

#=================ACOMODO======================
item=Button(raiz,text="Buscar", command=clicked)
rad1.grid(column=0, row=0)
rad2.grid(column=1, row=0)
rad3.grid(column=2, row=0)
rad4.grid(column=3, row=0)
rad5.grid(column=0, row=1)
rad6.grid(column=1, row=1)
rad7.grid(column=2, row=1)
rad8.grid(column=3, row=1)
rad9.grid(column=0, row=2)
rad10.grid(column=1, row=2)
rad11.grid(column=2, row=2)
rad12.grid(column=3, row=2)
rad13.grid(column=0, row=3)
rad14.grid(column=1, row=3)
rad15.grid(column=2, row=3)
rad16.grid(column=3, row=3)
rad17.grid(column=0, row=4)
rad18.grid(column=1, row=4)
rad19.grid(column=2, row=4)
rad20.grid(column=3, row=4)
rad21.grid(column=0, row=5)
rad22.grid(column=1, row=5)
rad23.grid(column=2, row=5)
rad24.grid(column=3, row=5)
rad25.grid(column=0, row=6)
rad26.grid(column=1, row=6)
rad27.grid(column=2, row=6)
rad28.grid(column=3, row=6)
rad29.grid(column=0, row=7)
rad30.grid(column=1, row=7)
rad31.grid(column=2, row=7)
rad32.grid(column=3, row=7)

item.grid(column=4, row=0)

raiz.mainloop()

