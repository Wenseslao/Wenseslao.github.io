# -*- coding: utf-8 -*-
"""
Created on Thu Oct 29 14:30:25 2020

@author: Bryan Cuellar Moran
"""
from tkinter import*
import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="",
  database="mexico"
)
mycursor = mydb.cursor()


def consulta():
    mycursor.execute("SELECT nombre FROM Estados")
    otra_ventana = Toplevel(raiz)
    myresult = mycursor.fetchall()
    Label(otra_ventana, text="Los estados que actualmente estan incluidos son:").pack()
    for x in myresult:
        Label(otra_ventana, text=str(x[0]),font=("Arial",10),).pack()
    
    Estado=Entry(otra_ventana)
    Estado.pack()
    raiz.iconify()
    
    def impresion():
        a=Estado.get()
        b="'"
        otra_ventana = Toplevel(raiz)
        otra_ventana.config(bg="black")
        sqlA = ("SELECT  \
            Estados.nombre AS ala, \
            datos.Contagios,datos.Hospitalizados,datos.Fallecidos,datos.Recuperados AS fav \
            FROM Estados \
            INNER JOIN Datos ON Estados.claveE =datos.claveD AND estados.Nombre= '"+str(a)+str(b))
        mycursor.execute(sqlA)
        Muestra = mycursor.fetchall()
        for x in Muestra:
            Label(otra_ventana, text="Estado: "+str(x[0]), font=("Arial",15), bg="light Green").pack()
            Label(otra_ventana, text="Contagios: "+str(x[1]),font=("Arial",15), bg="light Green").pack()
            Label(otra_ventana, text="Hospitalizados: "+str(x[2]),font=("Arial",15), bg="light Green").pack()
            Label(otra_ventana, text="Fallecidos: "+str(x[3]),font=("Arial",15), bg="light Green").pack()
            Label(otra_ventana, text="Recuperados: "+str(x[4]),font=("Arial",15), bg="light Green").pack()

        
    boton = Button(otra_ventana, text="Consultar", command=impresion, bg="yellow").pack()
    
    
def Agregar():
    
    otra_ventana = Toplevel(raiz)
    raiz.iconify()
    mycursor.execute("SELECT * FROM Estados")
    myresult = mycursor.fetchall()
    Label(otra_ventana, text="Los estados que actualmente estan incluidos son:").pack()
    for x in myresult:
        Label(otra_ventana, text=str(x[0])+" y su clave es "+str(x[1]),font=("Arial",10)).pack()

  
    
    def Introducir():
        otra_ventana = Toplevel(raiz)
        raiz.iconify()
        Label(otra_ventana, text="Nombre del estado").pack()
        Estado=Entry(otra_ventana)
        Estado.pack()
        Label(otra_ventana, text="Clave ").pack()
        Clave=Entry(otra_ventana)
        Clave.pack()

        def Introducir2():
            sql = "INSERT INTO Estados (claveE,Nombre) VALUES (%s, %s)"
            a1=Estado.get()
            b1=Clave.get()
            val = (b1,a1)
            mycursor.execute(sql, val)
            mydb.commit() 
            print(mycursor.rowcount, "Datos agregados")
            otra_ventana2 = Toplevel(otra_ventana)
            otra_ventana.iconify()
            Label(otra_ventana2, text="Contagios").pack()
            Contagios=Entry(otra_ventana2)
            Contagios.pack()

            Label(otra_ventana2, text="Hospitalizados ").pack()
            Hos=Entry(otra_ventana2)
            Hos.pack()

            Label(otra_ventana2, text="Fallecidos ").pack()
            Fall=Entry(otra_ventana2)
            Fall.pack()

            Label(otra_ventana2, text="Recuperados ").pack()
            Rec=Entry(otra_ventana2)
            Rec.pack()
            
            def mostrar():
                b1=Clave.get()
                c1=Contagios.get()
                d1=Hos.get()
                e1=Fall.get()
                f1=Rec.get()
                sql = "INSERT INTO Datos (claveD,Contagios,Hospitalizados,Fallecidos,Recuperados) VALUES (%s, %s,%s, %s,%s)"
                val = (b1,c1,d1,e1,f1)
                mycursor.execute(sql, val)
                mydb.commit() 
                print(mycursor.rowcount, "Datos agregados")
                otra_ventana2.destroy()
                
            boton3 = Button(otra_ventana2, text="Guardar datos ", command=mostrar,bg="yellow").pack()

        boton2 = Button(otra_ventana, text="Agregar datos ", command=Introducir2,bg="yellow").pack()
        
    boton1 = Button(otra_ventana, text="Agregar Estado ", command=Introducir,bg="yellow").pack()

def Eliminar():
    otra_ventana = Toplevel(raiz)
    raiz.iconify()
    mycursor.execute("SELECT * FROM Estados")
    myresult = mycursor.fetchall()
    Label(otra_ventana, text="Los estados que actualmente estan incluidos son:").pack()
    for x in myresult:
        Label(otra_ventana, text=str(x[0])+" y su clave es "+str(x[1]),font=("Arial",10)).pack()
        
    Label(otra_ventana, text=" Introduce el valor de la clave para eliminar ese estado ",font=("Arial",10),).pack()
    Estado=Entry(otra_ventana)
    Estado.pack()
    def Adios():
        a=Estado.get()
        b="'"
        sql = ("DELETE FROM Estados WHERE ClaveE= '"+str(a)+str(b))
        sql2 = ("DELETE FROM datos WHERE claveD= '"+str(a)+str(b))
        mycursor.execute(sql)
        mycursor.execute(sql2)
        mydb.commit()
        print(mycursor.rowcount, "eliminado")
        otra_ventana.destroy()
    
    


    
    Adios=Button(otra_ventana,text="Eliminar", height=1,bg="Red",font=("Arial",10), command=Adios).pack()
    


  

raiz=Tk()
raiz.title("Menu de bases de datos COVID-19 Mexico ")

Label(raiz, text="Menu Base de Datos",font=("Arial",15)).grid(row=0, column=0)
Label(raiz, text="Selecciona una opcion: ",font=("Arial",10)).grid(row=1, column=0)
B1=Button(raiz,text="Consultar estados", height=2,bg="yellow", command=consulta)
B1.grid(row=2,column=0)
B2=Button(raiz,text="Agregar estados",height=2,bg="yellow", command=Agregar)
B2.grid(row=3,column=0)
B3=Button(raiz,text="Eliminar Estados",height=2,bg="yellow", command=Eliminar)
B3.grid(row=4,column=0)


    


