import cv2
import numpy as np
 
img = cv2.imread("globoaz.jpg")
 
azul_bajo = np.array([40,0,0])
azul_alto = np.array([255, 120, 120])

mask = cv2.inRange(img, azul_bajo, azul_alto)
cv2.imshow("Original", img)
cv2.imshow("copia detectando Azul", mask)
 
print("pulsa pa salir \n")
cv2.waitKey(0)
cv2.destroyAllWindows()
