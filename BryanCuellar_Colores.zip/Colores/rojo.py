import cv2
import numpy as np
 
img = cv2.imread("globorojo.jpg")
rojo_bajo = np.array([0,0,70])
rojo_alto = np.array([120, 120, 255])
mask = cv2.inRange(img, rojo_bajo, rojo_alto)
cv2.imshow("Original", img)
cv2.imshow("Copia detectando rojo", mask)
print("Pulsa para salir \n")
cv2.waitKey(0)
cv2.destroyAllWindows()
