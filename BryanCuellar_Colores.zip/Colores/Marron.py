import cv2
import numpy as np
img = cv2.imread("globoma.jpg")
marron_bajo = np.array([10,20,35])
marron_alto = np.array([123, 140, 190])
mask = cv2.inRange(img, marron_bajo, marron_alto)
cv2.imshow("Original", img)
cv2.imshow("Copia detectando marron", mask)
print("\nPulsa para salir")
cv2.waitKey(0)
cv2.destroyAllWindows()
